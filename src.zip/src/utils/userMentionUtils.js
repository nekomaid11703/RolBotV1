const { getGroupMetadata } = require("./groupUtils");
const { getUserProfile } = require("../services/userService");
const {
  getDisplayableIdentity,
  isSameIdentity,
} = require("./identityUtils");

function cleanText(value, fallback = "usuario") {
  const text = String(value || "").trim();
  return text || fallback;
}

function findParticipantDisplayName(participant) {
  if (!participant || typeof participant !== "object") {
    return "";
  }

  const candidates = [
    participant.notify,
    participant.name,
    participant.pushName,
    participant.displayName,
    participant.subject,
  ];

  for (const candidate of candidates) {
    const clean = String(candidate || "").trim();
    if (clean) {
      return clean;
    }
  }

  return "";
}

async function resolveTargetDisplayName(ctx, targetId, fallback = "usuario") {
  const cleanFallback = cleanText(fallback, "usuario");

  if (!targetId) {
    return cleanFallback;
  }

  try {
    const data = await getUserProfile({ creatorId: targetId });
    const storedName =
      data?.profile?.metadata?.displayName ||
      data?.profile?.creatorName;

    const cleanStoredName = String(storedName || "").trim();

    if (cleanStoredName && cleanStoredName.toLowerCase() !== "usuario") {
      return cleanStoredName;
    }
  } catch {
    // Ignore profile lookup errors and continue with other sources.
  }

  try {
    if (ctx?.sock && ctx?.from && String(ctx.from).endsWith("@g.us")) {
      const metadata = await getGroupMetadata(ctx.sock, ctx.from);

      const participant = Array.isArray(metadata?.participants)
        ? metadata.participants.find((entry) =>
            isSameIdentity(
              entry?.id || entry?.jid || entry?.userId,
              targetId,
            ),
          )
        : null;

      const participantName = findParticipantDisplayName(participant);

      if (participantName) {
        return participantName;
      }
    }
  } catch {
    // Ignore group metadata errors too.
  }

  const displayable = getDisplayableIdentity(targetId);

  if (displayable) {
    return displayable;
  }

  return cleanFallback;
}

function withMentions(text, mentions = []) {
  return {
    text,
    mentions: [...new Set((Array.isArray(mentions) ? mentions : []).filter(Boolean))],
  };
}

module.exports = {
  resolveTargetDisplayName,
  withMentions,
};
